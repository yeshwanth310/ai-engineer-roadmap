# PY-B1 pilot setup (one time, ~10 min; time it separately from the lesson)

In Git Bash, in your `o2c-agent` folder (outside OneDrive):

1. `py -3.14 -m venv .venv`
2. `source .venv/Scripts/activate`  (prompt shows `(.venv)`; do this at the start of every session, then `py` uses the venv)
3. `py -m pip install -r requirements.txt`
4. `py -c "import sys; print(sys.prefix)"`  → must end in `.venv`
5. `py -m pytest --version`  → must print `pytest 9.1.1`

If `python` ever hangs, use `winpty python` (fallback only).
The build step (`build.md`) needs the S0 data generator, which isn't written yet: skip it for this pilot.
