# PY-B1 quiz (10 min, auto-checked on the site; answers are hidden until submitted)

1. What does `"3" + "3"` give? a) `6` b) `"33"` c) error. **Answer: b.** `+` on two strings joins them.
2. What type does `7 / 7` return? a) `int` b) `float`. **Answer: b.** `/` always returns a float (`1.0`).
3. Which builds an exact 0.1? a) `Decimal(0.1)` b) `Decimal("0.1")`. **Answer: b.** A float argument copies the float's binary error.
4. `Decimal("0.125").quantize(Decimal("0.01"))` gives? a) `0.12` b) `0.13`. **Answer: a.** The default is ROUND_HALF_EVEN. You need `rounding=ROUND_HALF_UP` to get 0.13.
5. After `c = " inr "` and then `c.upper()`, what is `c`? (type it) **Answer: `" inr "`.** Strings are immutable, so the result was thrown away.
6. `"4500012".zfill(10)` gives? (type it) **Answer: `"0004500012"`.**
7. Which of these is truthy? a) `""` b) `"0"` c) `Decimal("0")` d) `None`. **Answer: b.** It's a non-empty string.
8. `Decimal("0") or Decimal("5")` gives? a) `Decimal('0')` b) `Decimal('5')`. **Answer: b.** This is why `or` defaults are only for text.
9. `f"{Decimal('1234567.5'):,.2f}"` gives? (type it) **Answer: `"1,234,567.50"`.**
10. What happens with `Decimal("1.5") + 1.5`? a) `3.0` b) `Decimal('3.0')` c) `TypeError`. **Answer: c.** Python refuses to mix the two, so you convert at the edge.

Pass mark: 8/10. Each wrong answer links back to the section that covers it.
