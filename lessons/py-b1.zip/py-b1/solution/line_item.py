from decimal import Decimal, ROUND_HALF_UP

description_text = input()
quantity_text = input()
price_text = input()
currency_text = input()
discount_text = input()

description = description_text.strip()
quantity = int(quantity_text)
net_price = Decimal(price_text.strip())
currency = currency_text.strip().upper()
discount_percent = Decimal(discount_text.strip() or "0")

net_value = (quantity * net_price * (100 - discount_percent) / 100).quantize(
    Decimal("0.01"), rounding=ROUND_HALF_UP
)

print(
    f"{description} | qty {quantity} | {net_price:,} {currency} each | "
    f"{discount_percent}% off | net {net_value:,.2f} {currency}"
)
