"""Build check for PY-B1. Runs your script and checks what it produced."""
import runpy
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "order_line_prompt.py"


def load():
    return runpy.run_path(str(SCRIPT), run_name="not_main")


def test_document_numbers_are_normalised():
    g = load()
    assert isinstance(g["vbeln"], str) and len(g["vbeln"]) == 10 and g["vbeln"].isdigit()
    assert isinstance(g["posnr"], str) and len(g["posnr"]) == 6 and g["posnr"].isdigit()


def test_net_value_is_exact_and_half_up():
    g = load()
    net = g["net_value"]
    assert isinstance(net, Decimal), "net_value must be a Decimal"
    assert net.as_tuple().exponent == -2, "quantize to exactly 2 places"
    expected = (g["quantity"] * g["net_price"] * (100 - g["discount_percent"]) / 100).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    assert net == expected


def test_line_and_prompt_contain_the_facts():
    g = load()
    amount = f"{g['net_value']:,.2f}"
    assert amount in g["line"]
    assert g["vbeln"] in g["prompt"] and amount in g["prompt"]
    assert "SD" in g["prompt"]


def test_no_float_in_source():
    assert "float(" not in SCRIPT.read_text(encoding="utf-8")
