# PY-B1 pilot: files and a self-check against the locked bar
- `lesson.md`: the Learn block (~4,300 words including code, about 40 min with typing along)
- `quiz.md`: 10 auto-checked questions, pass mark 8/10
- `exercise/`: `line_item.py` starter, README, `test_line_item.py` (9 checks)
- `solution/line_item.py`: reference solution
- `build.md` + `build_check/test_order_line_prompt.py`: the agent layer and its test

Verified on Python 3.14.8 with pytest 9.1.1 (Researcher re-run; first run on 3.13 gave identical results). The build check still needs the S0 generator's `data/order_items.csv` before it can run in his repo:
the starter fails 8 of 9 checks and the solution passes 9/9. Three deliberately broken versions are each caught: float conversion fails 5, a missing ROUND_HALF_UP fails 2, and the wrong price format fails 3. A sample build script passes the build check 4/4.
Every numeric output shown in the lesson was run and copied from a real Python session, not typed from memory.

| Bar item | How PY-B1 meets it |
|---|---|
| A. Levels | Each topic has labelled Beginner and Intermediate sections, plus an Advanced line naming the later session (just in time) |
| B. Six parts | Each of topics 1–6 has what / why / underneath / worked example / common mistakes / in the agent |
| C. Analogy | One per topic plus one for the whole flow, each with a "where it breaks down" line |
| 1 Fills the time | ~4,300 words of on-page teaching; outside links are optional extras |
| 2 Specific links | Section-level doc links with time estimates (the CS50P lecture time is TBD from its chapter list) |
| 3 Proven | Auto-checked exercise with edge cases (rounding rule, blank vs zero, bad input must crash) plus a repo test for the build |
| 4 Output used | `order_line_prompt.py` feeds PY-B2 (list of items), LLM-3 (template), TOOL-1 (DB lookup) |
| 5 Accurate today | Python 3.14 target, `py`/Git Bash/venv per Setup, pytest 9.1.1 pinned, outputs run, not recalled |
| 6 No filler | Every topic is used in the exercise or the build |
| 7 Nothing before taught | The only non-taught things are the `import` line (explained in place) and pytest (run, not written; taught in PY-I5) |

Dependencies on other sessions: S0's generator must write `data/order_items.csv` with `vbeln, posnr, material, quantity, net_price, currency, discount_percent`. AI-0's script must be `scripts/ask.py` with a question variable.
The further-reading links are standard docs.python.org pages and the CS50P page Researcher already checked. Researcher should confirm the four docs.python.org URLs before publishing.

## Concept and example markers (for the final-pass scan)
Every concept is marked `<span data-concept="ID"></span>` where it is first shown, and every runnable example is marked `<span data-example-for="ID"></span>` just before its code fence. PY-B1 has 23 concepts and 24 examples, and no concept is left without an example. Later sessions copy this convention: IDs are kebab-case and unique within a session, and the engine prefixes them with the session ID (for example `PY-B1/decimal-quantize-half-up`).
