# PY-B1 exercise: one sales-order line (30 min)

Fill in `line_item.py` so that it reads **five lines** from input, in this order:
1. material description (may have extra spaces)
2. quantity, a whole number (may have leading zeros or spaces)
3. net price per unit, a decimal like `1234.50` (may have spaces)
4. currency code (any case, may have spaces)
5. discount percent, like `10` or `12.5`. **It may be blank, meaning 0.**

It must print exactly one line in this format:
```
Steel coil | qty 3 | 1,234.50 INR each | 10% off | net 3,333.15 INR
```
Rules:
- net value = quantity × price × (100 − discount) / 100, rounded **once** at the end to 2 places with `ROUND_HALF_UP`
- the unit price is shown with thousands separators and **its own decimals** (format spec `,`)
- the net value is shown with `,.2f`
- **no `float` and no `round()` anywhere**: money is `Decimal`
- bad input (a quantity of `2.5`, a price of `1,234.50`) must **crash with Python's own error**. Don't hide it; handling errors comes in PY-B4.

Check your work. Activate the venv first (`source .venv/Scripts/activate`), then `py` uses it:
```bash
py -m pytest -q
```
You haven't learned pytest yet (that's PY-I5). For now, read only the last line: `9 passed` means you're done. A failure prints the input it tried and the line it expected, which is your hint. Starting point: 8 of 9 tests fail (the "no float" check already passes). If you're stuck for more than 10 minutes, compare with `../solution/line_item.py`.
