from decimal import Decimal, ROUND_HALF_UP

description_text = input()
quantity_text = input()
price_text = input()
currency_text = input()
discount_text = input()

# TODO 1: remove surrounding spaces from the description
description = description_text

# TODO 2: convert the quantity text to an int
quantity = quantity_text

# TODO 3: convert the price text to a Decimal (from the string, never via float)
net_price = price_text

# TODO 4: normalise the currency: no surrounding spaces, upper case
currency = currency_text

# TODO 5: blank discount means "0" (hint: `or` on the TEXT), then convert to Decimal
discount_percent = discount_text

# TODO 6: compute the net value and quantize ONCE with ROUND_HALF_UP to 2 places
net_value = "TODO"

# TODO 7: print the line in the exact format from README.md using one f-string
print("TODO")
