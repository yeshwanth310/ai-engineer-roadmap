"""Checks for PY-B1. You don't need to read this yet: pytest is taught in PY-I5."""
import os
import subprocess
import sys
from pathlib import Path

import pytest

SCRIPT = Path(os.environ.get("LINE_ITEM_SCRIPT", Path(__file__).with_name("line_item.py")))


def run(*lines):
    return subprocess.run(
        [sys.executable, str(SCRIPT)],
        input="\n".join(lines) + "\n",
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=10,
    )


CASES = [
    # (description, qty, price, currency, discount) -> expected line
    (("Steel coil", "3", "1234.50", "inr", "10"),
     "Steel coil | qty 3 | 1,234.50 INR each | 10% off | net 3,333.15 INR"),
    # blank discount means 0; currency with spaces and lower case
    (("Pallet", "2", "0.10", " eur ", ""),
     "Pallet | qty 2 | 0.10 EUR each | 0% off | net 0.20 EUR"),
    # commercial rounding: half-up gives .13, banker's rounding would give .12
    (("Washer", "1", "0.125", "USD", ""),
     "Washer | qty 1 | 0.125 USD each | 0% off | net 0.13 USD"),
    # float maths gives 69.96 here; Decimal with ROUND_HALF_UP gives 69.97
    (("Gasket", "4", "19.99", "USD", "12.5"),
     "Gasket | qty 4 | 19.99 USD each | 12.5% off | net 69.97 USD"),
    # leading zeros, padded description and price, large values, explicit zero discount
    (("  Bolt M8  ", "007", " 1000000 ", "INR", "0"),
     "Bolt M8 | qty 7 | 1,000,000 INR each | 0% off | net 7,000,000.00 INR"),
    # float would print 2.67 here
    (("Clamp", "1", "2.675", "INR", ""),
     "Clamp | qty 1 | 2.675 INR each | 0% off | net 2.68 INR"),
]


@pytest.mark.parametrize("inputs, expected", CASES)
def test_line(inputs, expected):
    result = run(*inputs)
    assert result.returncode == 0, f"Script crashed for {inputs}:\n{result.stderr}"
    assert result.stdout.strip() == expected, f"Input {inputs}"


def test_price_with_thousands_separator_fails_loudly():
    result = run("Coil", "1", "1,234.50", "INR", "")
    assert result.returncode != 0, "A price like '1,234.50' must crash, not be guessed"
    assert "InvalidOperation" in result.stderr


def test_fractional_quantity_fails_loudly():
    result = run("Coil", "2.5", "10.00", "INR", "")
    assert result.returncode != 0, "A quantity like '2.5' must crash"
    assert "ValueError" in result.stderr


def test_no_float_or_round_in_source():
    source = SCRIPT.read_text(encoding="utf-8")
    assert "float(" not in source and "round(" not in source, "Money must stay Decimal"
