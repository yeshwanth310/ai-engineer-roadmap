# PY-B1 build: the agent's first prompt line (40 min)

**Layer added to the order-to-cash agent:** `scripts/order_line_prompt.py`. It turns one real item from your synthetic SD data into (a) a correctly rounded, formatted line and (b) the first prompt the agent will send to Gemini about it. PY-B2 turns this single item into a list of items, LLM-3 moves the prompt into a versioned template, and TOOL-1 replaces the hand-copied values with a database lookup.

**Steps**
1. (5 min) Open `data/order_items.csv` (made by the S0 generator) in VS Code. Pick **one** row and copy its `vbeln`, `posnr`, `material`, `quantity`, `net_price`, `currency` and `discount_percent` values.
2. (15 min) In `o2c-agent/scripts/order_line_prompt.py`, set those values as **strings**, exactly as they look in the CSV, then:
   - normalise `vbeln` to 10 digits (`.strip().zfill(10)`), and keep it as `vbeln`
   - format the item number as 6 digits with an f-string (`f"{int(posnr_text):06}"`), and keep it as `posnr`
   - convert quantity to `int`, price and discount to `Decimal`
   - compute `net_value`, quantized once with `ROUND_HALF_UP`
   - build `line` with the exercise's format, and `prompt` as a triple-quoted f-string that tells the model it's an SAP SD assistant, gives the order, item, material and net value, and asks: "Is this net value consistent with quantity, price and discount? Answer yes or no and show the calculation."
   - `print(line)`, then `print(prompt)`
3. (10 min) Copy `build_check/test_order_line_prompt.py` into `o2c-agent/tests/` and, with the venv activated, run `py -m pytest -q tests/test_order_line_prompt.py`. It checks the **behaviour**: 10-digit `vbeln`, 6-digit `posnr`, the net value is a `Decimal` with exactly 2 places that equals the half-up calculation, the prompt contains the order number and the formatted amount, and there's no `float` in the file.
4. (5 min) Paste your printed prompt in as the question in the AI-0 script (`scripts/ask.py`) and run it. Gemini should confirm your calculation. If it disagrees, trust the `Decimal` maths and note what it got wrong in `progress.md`. That's your first piece of evidence for why the agent will later *compute* with tools instead of asking the model to do arithmetic (TOOL-1).
5. (5 min) Add a line to `progress.md` ("PY-B1: order line + first prompt; test passes"), then commit on a branch and open a PR to yourself (GIT-2).

**Done means:** the test passes in the repo, and the commit is pushed.
