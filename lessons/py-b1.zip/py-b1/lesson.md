# PY-B1 · Values, types, strings and money
**Week 6 · Python ladder, Basics, session 1 of 6 · Pilot written to the locked standing quality bar**

| Block | Minutes | What you do |
|---|---|---|
| Learn (this page) | 40 | Read and type every example into `py` |
| Quiz | 10 | `quiz.md`, 10 questions, auto-checked |
| **HALFWAY: stop here on a busy week. Learn + Quiz is the minimum week.** | | |
| Exercise | 30 | `exercise/line_item.py`, checked by `py -m pytest` |
| Build | 40 | `build.md`: the first real piece of the order-to-cash agent, plus a commit |

**Before you start.** Setup (S0) is done: Python 3.14 is installed, your `o2c-agent` folder exists outside OneDrive, and the virtual environment is active (`source .venv/Scripts/activate` in Git Bash, so your prompt shows `(.venv)`). Activate first, every session; then `py` uses the venv (without activation `py` runs the global Python, which has no pytest). Open the Python prompt with `py`. You'll see `>>>`. Type each example yourself instead of copying it, because typing is how the syntax sticks. Leave the prompt with `exit()`.

**What you'll be able to do by the end.** Read one sales-order item typed in as text, turn it into the right Python types, calculate a net value to the paisa with the right rounding rule, and print a clean, aligned line, the kind of line the agent will later hand to Gemini. Every later session builds on these exact skills. Python reads every LLM reply, every database row and every API response as one of the types on this page.

**Python prerequisites:** none. This is the first Python session. Everything used on this page, including the single `import` line, is explained here.

**Levels on this page.** Each topic is labelled. **Beginner** and **Intermediate** are taught here in full. **Advanced** gets one line saying where it's taught, just before you need it, so this page doesn't turn into months of theory.

---

## 1. Values, types and variables

### Beginner
**What it is.** A *value* is a piece of data: `42`, `"4500012"`, `19.99`. Every value has a *type*, which decides what you can do with it. A *variable* is a name you attach to a value with `=`.

<span data-concept="values-types-variables"></span><span data-example-for="values-types-variables"></span>
```python
>>> quantity = 3
>>> order_number = "4500012"
>>> type(quantity)
<class 'int'>
>>> type(order_number)
<class 'str'>
```

**Why it matters.** `3` and `"3"` look alike on screen but behave completely differently. `3 + 3` is `6`. `"3" + "3"` is `"33"`. `"3" + 3` is an error. Almost everything that reaches your agent arrives as text: a user's question, a CSV cell, an LLM's JSON. Turning text into the right type is the first job in nearly every script you'll write.

**Worked example.**
<span data-concept="type-decides-operations"></span><span data-example-for="type-decides-operations"></span>
```python
>>> "5" + "5"
'55'
>>> 5 + 5
10
>>> "5" * 3          # repeat the text three times
'555'
>>> int("5") + 5     # convert first, then add
10
```

### Intermediate
**How it works underneath.** In Python, the type belongs to the *value*, not to the variable. A variable is a label stuck onto an object in memory, and you can move the same label to a different object of a different type:

<span data-concept="names-are-labels"></span><span data-example-for="names-are-labels"></span>
```python
>>> x = 3
>>> type(x)
<class 'int'>
>>> x = "three"      # legal: the label x now points at a str
>>> type(x)
<class 'str'>
```

This is called *dynamic typing*. Python checks types while the code runs, not before. The upside is short code. The downside is that a wrong type only blows up on the line that uses it, which may be far from where the bad value came in. Type hints (PY-I3) and Pydantic (PY-A1) exist to catch that earlier.

Assigning one variable to another copies the *label*, not the object:
<span data-concept="assignment-copies-label"></span><span data-example-for="assignment-copies-label"></span>
```python
>>> a = "4500012"
>>> b = a           # b points at the same str object as a
>>> a = a.zfill(10) # a now points at a NEW str; b is unchanged
>>> a, b
('0004500012', '4500012')
```
`b` didn't change because strings can't be changed in place (section 4). With lists, which *can* change in place, the same pattern causes the most common bug in agent code: a shared message history edited by accident. PY-B2 covers that in depth, so keep this picture of labels and objects in mind.

**Common mistakes.**
- Treating anything read from `input()`, a file or an API as a number. It's a `str` until you convert it.
- Reusing one variable name for different kinds of thing (`order = "4500012"`, later `order = 3`). It's legal and confusing. One name, one meaning.
- Names that hide built-ins: `str = "abc"` breaks `str()` for the rest of the session. Avoid `str`, `list`, `type`, `input`, `sum` and `id` as names.

**In the order-to-cash agent.** Every tool the agent calls (TOOL-1) receives its arguments from Gemini as JSON text. Your code converts them into `int`, `Decimal` and `str` values before it touches the database. Getting the type wrong there means a wrong SQL filter or a wrong amount shown to a user.

**Analogy.** Types are like SAP data elements and domains. A `CURR` field, a `QUAN` field and a `CHAR` field can all display "100", but the system treats them differently: currency gets currency decimals, quantity gets a unit, and characters are just text. **Where it breaks down:** SAP checks a field's type when the program is activated and the field is fixed to it. Python checks types only when the line runs, and a variable can switch type at any time.

**Advanced (later):** static type checking with mypy or pyright comes in PY-I3, and runtime validation with Pydantic in PY-A1.

---

## 2. Numbers: `int` and `float`

### Beginner
**What it is.** `int` holds whole numbers of any size. `float` holds numbers with a decimal point. The main operators are `+ - * /`, plus `//` (whole-number division), `%` (remainder) and `**` (power).

<span data-concept="int-float-operators"></span><span data-example-for="int-float-operators"></span>
```python
>>> 7 / 2      # true division ALWAYS gives a float
3.5
>>> 7 // 2     # floor division: rounds DOWN to a whole number
3
>>> 7 % 2      # remainder
1
>>> 2 ** 10
1024
>>> 1_000_000  # underscores are allowed for readability
1000000
```

**Why it matters.** Quantities, line-item numbers, counts and token counts are `int`. Scores, probabilities and an LLM's temperature setting are `float`. Money is neither, as section 3 explains.

**Worked example: splitting a delivery.** 1,250 pieces go on pallets that hold 200 each.
<span data-example-for="int-float-operators"></span>
```python
>>> pieces = 1250
>>> full_pallets = pieces // 200
>>> leftover = pieces % 200
>>> full_pallets, leftover
(6, 50)
```

Converting text into numbers:
<span data-concept="text-to-number"></span><span data-example-for="text-to-number"></span>
```python
>>> int("007")      # leading zeros are fine
7
>>> int(" 42 ")     # surrounding spaces are fine
42
>>> int("12.5")     # but not a decimal point
ValueError: invalid literal for int() with base 10: '12.5'
>>> float("12.5")
12.5
```

### Intermediate
**How it works underneath.** A Python `int` has no size limit. `10**20 + 1` is exact. A `float` is a 64-bit IEEE 754 binary number: about 15–17 significant digits, stored in base 2. Most decimal fractions, including 0.1, *can't be stored exactly in base 2*, just as 1/3 can't be written exactly in base 10. So Python stores the nearest binary value:

<span data-concept="float-binary-error"></span><span data-example-for="float-binary-error"></span>
```python
>>> 0.1 + 0.2
0.30000000000000004
>>> 0.1 * 3 == 0.3
False
```
This isn't a Python bug. Excel, JavaScript and Java `double` all do the same thing. It also explains a surprise in the built-in `round()`:
<span data-concept="round-builtin-surprise"></span><span data-example-for="round-builtin-surprise"></span>
```python
>>> round(2.675, 2)
2.67                # you expected 2.68
```
2.675 is actually stored as 2.67499999…, so it rounds down. On top of that, `round()` uses *banker's rounding* (round half to even) for exact halves: `round(2.5)` is `2` and `round(3.5)` is `4`.

**Common mistakes.**
- Expecting `/` to give an `int`. It never does. Use `//` when you want a whole number, and remember `//` rounds toward minus infinity, so `-7 // 2` is `-4`.
- Comparing floats with `==`. For scores, compare with a tolerance instead (`math.isclose`, later).
- Using `float` for money. That's the next section.

**In the order-to-cash agent.** Order quantities, `POSNR`-style item numbers and token counts are `int`. Similarity scores in RAG (RAG-1) and model temperature are `float`. Amounts are never `float`.

**Analogy.** A `float` is like a measuring tape marked in inches when your drawing is in centimetres. You can always get *close*, but almost no centimetre value lands exactly on a mark. **Where it breaks down:** the error is far smaller than any tape (around the 16th digit), but it adds up in sums and decides which way rounding goes, which is exactly what matters for money.

**Advanced (later):** `math.isclose`, `fractions` and numeric precision for embeddings come up in RAG-1.

---

## 3. Money with `Decimal`

### Beginner
**What it is.** `Decimal` is a number type from Python's standard library that stores numbers *in base 10, exactly as written*. It isn't built into the language like `int`, so you bring it in with an **import line**:

<span data-concept="decimal-exact"></span>
```python
>>> from decimal import Decimal
```
Read it as "from the `decimal` module, give me the name `Decimal`". A *module* is a file of ready-made Python code. You'll learn how modules work, and how to write your own, in PY-I1. For now, an import line goes at the top of a script and makes a name available.

<span data-example-for="decimal-exact"></span>
```python
>>> Decimal("0.1") + Decimal("0.2")
Decimal('0.3')
>>> Decimal("0.1") * 3 == Decimal("0.3")
True
```

**Why it matters.** Billing is the core of order-to-cash. A net value that's off by one paisa on one line becomes a reconciliation problem across ten thousand invoices, and an agent that says "the open amount is 3,333.14" when SAP says 3,333.15 loses the user's trust in one answer.

**Worked example: a line net value.**
<span data-concept="decimal-line-net-value"></span><span data-example-for="decimal-line-net-value"></span>
```python
>>> from decimal import Decimal
>>> quantity = 3
>>> net_price = Decimal("1234.50")
>>> discount_percent = Decimal("10")
>>> net_value = quantity * net_price * (100 - discount_percent) / 100
>>> net_value
Decimal('3333.150')
```
An `int` times a `Decimal` gives a `Decimal`, so mixing those two is safe.

### Intermediate
**How it works underneath.** A `Decimal` stores a sign, a list of decimal digits and an exponent, so `Decimal("3333.150")` remembers that it has three decimal places. Arithmetic follows a *context* that sets the precision (28 significant digits by default) and the rounding rule. To round to a fixed number of places, you use `quantize` with an example of the places you want:

<span data-concept="decimal-quantize-half-up"></span><span data-example-for="decimal-quantize-half-up"></span>
```python
>>> from decimal import Decimal, ROUND_HALF_UP
>>> Decimal("0.125").quantize(Decimal("0.01"))
Decimal('0.12')                 # default rule: ROUND_HALF_EVEN (banker's)
>>> Decimal("0.125").quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
Decimal('0.13')                 # commercial rounding
```
Commercial rounding (`ROUND_HALF_UP`: a 5 always rounds away from zero) is what most invoices and most SAP pricing setups use. **Always name the rounding rule you mean.** Here's what the three approaches do with one realistic line, 4 × 19.99 with 12.5% off:

<span data-concept="rounding-rule-comparison"></span><span data-example-for="rounding-rule-comparison"></span>
```python
>>> 4 * 19.99 * 0.875                    # float
69.96499999999999
>>> round(4 * 19.99 * 0.875, 2)          # float + round()
69.96                                    # wrong by one paisa
>>> (4 * Decimal("19.99") * (100 - Decimal("12.5")) / 100).quantize(
...     Decimal("0.01"), rounding=ROUND_HALF_UP)
Decimal('69.97')                         # correct
```

**Common mistakes.**
- **Building a `Decimal` from a float**: `Decimal(0.1)` gives `Decimal('0.1000000000000000055511151231257827021181583404541015625')`. It faithfully copies the float's error. Always build from a **string**: `Decimal("0.1")`.
- **Mixing with float**: `Decimal("1.5") + 1.5` raises `TypeError: unsupported operand type(s)`. That's a good thing, because Python refuses to quietly lose your precision. Convert at the edge, once.
- **Thousands separators in input**: `Decimal("1,234.50")` raises `decimal.InvalidOperation`. Strip the separator first (`.replace(",", "")`), but only once you know which separator the source uses. In India and the US the comma groups thousands. In much of Europe it's the decimal mark.
- **Rounding at every step instead of once at the end.** Round the line total, not each intermediate result, unless the business rule says otherwise. In SAP, the pricing procedure decides this. In your code, *you* do.

**In the order-to-cash agent.** Every amount the agent reads from `o2c.db` becomes a `Decimal`. Every amount it shows is quantized with `ROUND_HALF_UP`. Q2 in the fixed SD question set ("total net value of open orders") is marked wrong if it's off by a paisa. When Gemini returns structured output in SO-1, amount fields are validated as `Decimal`, never `float`.

**Analogy.** `Decimal` is the `CURR` field paired with its currency key: the amount is stored exactly, and the number of decimals is a deliberate setting (like currency decimals in table TCURX), not an accident of storage. `float` is like keeping amounts in a floating-point (`FLTP`) field. **Where it breaks down:** SAP stores currency amounts as packed decimals with fixed places tied to the currency. A Python `Decimal` carries whatever places you give it, so *you* must quantize to the currency's decimals. Nothing does it for you.

**Advanced (later):** custom decimal contexts, rounding at document level versus item level, and multi-currency totals come in API-3 (cost tracking) and in DATA-1, where the generator produces currency-specific decimals.

---

## 4. Strings and string methods

### Beginner
**What it is.** A `str` is a sequence of Unicode characters inside quotes: `'single'`, `"double"`, or `"""triple"""` for text spanning several lines. You can measure, index and slice it:

<span data-concept="str-index-slice"></span><span data-example-for="str-index-slice"></span>
```python
>>> material = "Steel coil"
>>> len(material)
10
>>> material[0]       # first character (counting starts at 0)
'S'
>>> material[-4:]     # last four characters
'coil'
```

Methods are functions attached to a value and called with a dot. These are the ones you'll use every week:

| Method | What it does | Example | Result |
|---|---|---|---|
| `strip()` | remove spaces/newlines at both ends | `"  inr \n".strip()` | `'inr'` |
| `upper()` / `lower()` | change case | `"inr".upper()` | `'INR'` |
| `replace(a, b)` | replace every `a` with `b` | `"1,234.50".replace(",", "")` | `'1234.50'` |
| `split(sep)` | cut into a list of pieces | `"a;b;c".split(";")` | `['a', 'b', 'c']` |
| `startswith(x)` | test the beginning | `"4500012".startswith("45")` | `True` |
| `zfill(n)` | pad with leading zeros to length n | `"4500012".zfill(10)` | `'0004500012'` |
| `lstrip("0")` | remove leading zeros | `"0004500012".lstrip("0")` | `'4500012'` |
| `find(x)` | position of x, or -1 | `"abc".find("z")` | `-1` |

**Why it matters.** Users type document numbers with and without leading zeros, with spaces, and in any case. A database lookup for `"4500012"` won't find `"0004500012"`. Most "the agent says the order doesn't exist" bugs are string-cleaning bugs.

**Worked example: normalising a document number the way SAP does.**
<span data-concept="str-methods-normalise"></span><span data-example-for="str-methods-normalise"></span>
```python
>>> typed = "  4500012 "
>>> vbeln = typed.strip().zfill(10)
>>> vbeln
'0004500012'
```
Methods can be *chained* because each one returns a new string that the next one works on.

### Intermediate
**How it works underneath.** Strings are **immutable**: no method changes the original. `strip()`, `upper()` and the rest all return a *new* string.

<span data-concept="str-immutable"></span><span data-example-for="str-immutable"></span>
```python
>>> currency = " inr "
>>> currency.upper()
' INR '
>>> currency            # unchanged!
' inr '
>>> currency = currency.strip().upper()   # rebind the name to keep the result
>>> currency
'INR'
>>> currency[0] = "X"
TypeError: 'str' object does not support item assignment
```
Immutability makes strings safe to share. Nobody can change your copy behind your back, and it's why they can be used as dictionary keys (PY-B2).

Characters are Unicode code points, not bytes. `len("₹")` is `1`, but stored as UTF-8 it takes 3 bytes. That difference matters when you write files on Windows (PY-B5 teaches `encoding="utf-8"`) and when LLMs count tokens (LLM-1). Case-changing is also Unicode-aware: `"Straße".upper()` gives `'STRASSE'`. Faker's German customer names will produce exactly this in DATA-1.

**Common mistakes.**
- Calling a method and throwing away the result: `currency.strip()` on its own line does nothing useful.
- `lstrip("0")` on `"0000000000"` returns `''`, an empty string, not `"0"`. Check that edge case when you strip zeros.
- Comparing without normalising: `"INR" == "inr"` is `False`. Normalise both sides (`.strip().upper()`) before comparing codes.
- Building long text with `+` in many steps. Use an f-string (section 5).

**In the order-to-cash agent.** Every tool that takes a document number (`order_status`, `doc_flow` in TOOL-1) starts with `.strip().zfill(10)`, because Gemini will pass `"4500012"` when the user typed it that way. Currency and sales-org codes are normalised with `.strip().upper()`. Chunking in RAG-2 is string slicing at scale.

**Analogy.** `zfill(10)` is SAP's ALPHA conversion exit: the user sees `4500012`, and the database stores `0004500012`. Immutability is like a posted billing document: you never edit it, you create a new document (a cancellation and re-billing) and point at that instead. **Where it breaks down:** ALPHA conversion runs automatically on screen fields. In Python nothing is automatic, so every entry point has to call `zfill` itself. And making new strings costs nothing, unlike creating cancellation documents.

**Advanced (later):** regular expressions for pulling document numbers out of free text come in PY-B6. Unicode normalisation and token-aware splitting come in RAG-2.

---

## 5. f-strings: building text from values

### Beginner
**What it is.** An f-string is a string with `f` before the quote. Anything inside `{}` is evaluated and inserted:

<span data-concept="fstring-basics"></span><span data-example-for="fstring-basics"></span>
```python
>>> vbeln = "0004500012"
>>> quantity = 3
>>> f"Order {vbeln} has {quantity} items"
'Order 0004500012 has 3 items'
```

**Why it matters.** Prompts for Gemini (API-1), log lines (API-3) and every answer the agent prints are text built from values. f-strings are the clearest and fastest way to do it.

**Worked example: the format mini-language.** After a colon inside the braces, a *format spec* controls how the value looks:

<span data-concept="format-spec"></span><span data-example-for="format-spec"></span>
```python
>>> net = Decimal("1234567.5")
>>> f"{net:,.2f}"          # thousands separator, 2 decimals
'1,234,567.50'
>>> f"{12:06}"             # pad a number with zeros to width 6 (an item number like POSNR)
'000012'
>>> f"{'VBELN':<10}|"      # left-align in 10 characters
'VBELN     |'
>>> f"{42:>6}|"            # right-align in 6
'    42|'
>>> f"{0.5:.0%}"           # percentage
'50%'
>>> f"{quantity * 2 = }"   # debug form: shows the expression and its value
'quantity * 2 = 6'
```

### Intermediate
**How it works underneath.** Python evaluates each `{expression}` when that line runs, then calls `format(value, spec)` on the result. The *type* decides what the spec means. That's why `f"{Decimal('1234.50'):,}"` gives `'1,234.50'` and keeps the value's own two decimals, while `:.2f` forces two. One trap matters for money: **formatting rounds with the type's own rule**, and for a `Decimal` that's banker's rounding: `f"{Decimal('0.125'):.2f}"` gives `'0.12'`. So quantize with `ROUND_HALF_UP` first, then format.

Triple-quoted f-strings span several lines. This is how you'll write prompts:
<span data-concept="fstring-multiline-prompt"></span><span data-example-for="fstring-multiline-prompt"></span>
```python
>>> prompt = f"""You are an SAP SD assistant.
... Order: {vbeln}
... Net value: {net:,.2f} INR
... Answer in one sentence."""
```

**Common mistakes.**
- Forgetting the `f`: `"Order {vbeln}"` prints the braces literally.
- Letting the format spec do your money rounding. Quantize first.
- Literal braces in a prompt that shows JSON: inside an f-string, write `{{` and `}}` to get `{` and `}`. This will bite you in LLM-2 when prompts include JSON examples.
- Quotes inside quotes. Since Python 3.12 you may reuse the same quote type inside `{}`, but `f"{d['key']}"` (single inside double) is easier to read and works everywhere.
- Note that `,` in the format spec always groups in threes (1,234,567). Indian lakh/crore grouping (12,34,567) isn't built in. If a report needs it, that's a deliberate later choice, not a format spec.

**In the order-to-cash agent.** Your build step today produces the first prompt template. In LLM-3 it moves into a versioned prompt file, but the f-string thinking stays the same.

**Analogy.** An f-string is like an SD output form (an invoice layout in SmartForms or Adobe Forms): fixed text with fields that get filled from the document at print time, each field with its own format (amount with separators, date in your locale). **Where it breaks down:** an output form is designed once and filled many times. An f-string is filled immediately on the line where it's written. Reusable templates that are filled later are `str.format` and prompt files (LLM-3).

**Advanced (later):** reusable templates and prompt versioning in LLM-3; structured logging instead of f-strings in log calls in API-3.

---

## 6. `None` and truthiness

### Beginner
**What it is.** `None` is Python's single value for "nothing here": no discount, no block reason, no result found. Its type is `NoneType`. Test for it with `is`:

<span data-concept="none-is-test"></span><span data-example-for="none-is-test"></span>
```python
>>> block_reason = None
>>> block_reason is None
True
```

*Truthiness* means every value counts as true or false when Python needs a yes/no answer. These count as **false**: `None`, `False`, `0`, `0.0`, `Decimal("0")`, `""` (the empty string), and empty collections. Almost everything else counts as true, including the string `"0"` and the string `" "`.

<span data-concept="truthiness"></span><span data-example-for="truthiness"></span>
```python
>>> bool("")
False
>>> bool("0")       # a non-empty string, so True!
True
>>> bool(Decimal("0.00"))
False
```

**Why it matters.** Missing data is everywhere in SD data: no billing block, no PO number, a blank discount field. Your code has to tell "missing" apart from "zero" and "empty text".

**Worked example: a default for a blank field with `or`.** `a or b` gives `a` if `a` is truthy, otherwise `b`:
<span data-concept="or-default"></span><span data-example-for="or-default"></span>
```python
>>> discount_text = ""             # user left it blank
>>> discount_text or "0"
'0'
>>> discount_text = "12.5"
>>> discount_text or "0"
'12.5'
```

### Intermediate
**How it works underneath.** `None` is a *singleton*: there is exactly one `None` object in a running program. That's why `is None` (same object?) is the correct test and the idiomatic one. `== None` usually gives the same answer, but a class can redefine `==`, and `is` can't be fooled. `or` doesn't return `True`/`False`. It returns one of its two operands, which is what makes the default pattern above work. `and` works the same way, the other way round.

The trap: **`or` treats every falsy value as missing.** That's fine for text from `input()`, where `"0"` is truthy. It's wrong for a value that's already a number:
<span data-concept="or-falsy-trap"></span><span data-example-for="or-falsy-trap"></span>
```python
>>> discount = Decimal("0")        # a REAL zero discount
>>> discount or Decimal("5")       # meant as "default if missing"
Decimal('5')                       # wrong: the zero was replaced
```
Here you need to test for `None` explicitly, which needs `if` from PY-B2. For now: **use `or` for defaults only on text, before converting it.** That's exactly the order the exercise uses.

**Common mistakes.**
- `if value:` when you mean `if value is not None:` (PY-B2). Zero amounts and empty strings silently go down the wrong branch.
- Returning `None` by accident and then calling a method on it: `AttributeError: 'NoneType' object has no attribute 'strip'`. You'll learn to read that traceback in PY-B4.
- Thinking `None`, `0` and `""` are interchangeable. In a database they're `NULL`, `0` and an empty string, three different facts.

**In the order-to-cash agent.** "Is this order blocked?" is a question about whether `billing_block` is `None`. Q3 ("why is order 4500012 blocked?") depends on telling "no block" (`None`) apart from a block code. When Gemini omits an optional field in structured output (SO-1), Pydantic fills it with `None`, and your code has to handle that.

**Analogy.** `None` is an SAP field left at its *initial* value, for example an empty billing-block field on the order header. Truthiness is like a selection screen treating a blank field as "no restriction". **Where it breaks down:** SAP fields have no real "null". An empty `CHAR` field and an initial field are the same thing, and an initial `CURR` field is `0.00`. Python keeps `None`, `""` and `0` as three separate values, and good code keeps them separate.

**Advanced (later):** `Optional`/`X | None` type hints in PY-I3, and Pydantic defaults and missing fields in PY-A1.

---

## 7. Reading input and putting it together

`input()` pauses, reads one line that the user types (or that a test feeds in), and returns it **as a `str` without the trailing newline**. `print()` writes values to the screen. Here's the whole session in one script, with a comment (`#` to end of line) on each step:

<span data-concept="input-full-script"></span><span data-example-for="input-full-script"></span>
```python
from decimal import Decimal, ROUND_HALF_UP

quantity_text = input()              # e.g. "3"
price_text = input()                 # e.g. "1234.50"
currency_text = input()              # e.g. " inr "

quantity = int(quantity_text)                    # str -> int
net_price = Decimal(price_text.strip())          # str -> Decimal, never float
currency = currency_text.strip().upper()         # normalise the code

net_value = (quantity * net_price).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
print(f"qty {quantity} | {net_price:,} {currency} each | net {net_value:,.2f} {currency}")
```
Run it with `py script.py` and type three lines. Try `3`, `1234.50`, ` inr `, then try `3.5` as the quantity and read the error's last line: `ValueError`. Python fails loudly on bad input instead of guessing, and that's what you want in billing. Handling the error politely comes in PY-B4.

**Analogy for the whole flow.** It's an inbound IDoc: raw segments arrive as text, each field is converted and checked against its data element, and only then is the document posted. **Where it breaks down:** an IDoc has a status record and can be reprocessed. Here a failed conversion simply stops the script.

---

## What changed in Python 3.14 that touches this page
Nothing on this page changed in 3.14. Two things to know for later: Windows still opens text files with the system code page unless you pass `encoding="utf-8"` (PY-B5), and Python 3.12+ allows the same quote type inside f-string braces.

## Recap: the six things to remember
1. Text from outside is always `str` until you convert it.
2. `int` for counts, `Decimal` (built from strings) for money, `float` for scores, never for money.
3. Quantize once, at the end, with an explicit rule: `ROUND_HALF_UP`.
4. String methods return new strings. Rebind the name to keep the result.
5. f-strings with format specs build every line and prompt. Quantize before formatting money.
6. `None`, `0` and `""` are different facts. `or` defaults are for text only.

## Further reading (optional, after the session)
- Python tutorial: [Numbers](https://docs.python.org/3/tutorial/introduction.html#numbers) and [Text](https://docs.python.org/3/tutorial/introduction.html#text) (~20 m)
- [decimal: Quick-start tutorial](https://docs.python.org/3/library/decimal.html#quick-start-tutorial) (~15 m)
- [Format specification mini-language](https://docs.python.org/3/library/string.html#format-specification-mini-language) (~10 m, use as reference)
- [Floating-point arithmetic: issues and limitations](https://docs.python.org/3/tutorial/floatingpoint.html) (~10 m)
- [CS50P Week 0](https://cs50.harvard.edu/python/weeks/0/), the lecture as a second explanation (time to be confirmed from the lecture's chapter list)
